<template>
  <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
  <div class="user-register">
    <h2>Register</h2>
    <form @submit.prevent="register">
      <div style="text-align:left">
        <label for="username"  style="text-align:left">Username:</label>
        <input type="text" id="username" class="form-control" v-model="username" required>
      </div>
      <div style="text-align:left">
        <label for="firstname" >Firstname:</label>
        <input type="text" id="firstname" class="form-control" v-model="firstname" required>
      </div>
      <div style="text-align:left">
        <label for="lastname" >Lastname:</label>
        <input type="text" id="lastname" class="form-control" v-model="lastname" required>
      </div>
      <div style="text-align:left">
        <label for="gender" >Gender:</label>
        <select class="form-control" id="gender"  v-model="gender" required>
          <option value="male">Male</option>
          <option value="female">Female</option>
          <option value="other">Other</option>
        </select>
      </div>
      <div style="text-align:left">
        <label for="address" >Address:</label>
        <textarea id="address" v-model="address" required class="form-control"></textarea>
      </div>
      <div style="text-align:left">
        <label for="mobile" >Mobile:</label>
        <input type="text" id="mobile" class="form-control" v-model="mobile" required>
      </div>
      <div style="text-align:left">
        <label for="dob" >Dob:</label>
        <input type="date" id="dob" class="form-control" v-model="dob" required>
      </div>
      <div style="text-align:left">
        <label for="email" >Email:</label>
        <input type="email" id="email" class="form-control" v-model="email" required>
      </div>
      <div style="text-align:left">
        <label for="password" >Password:</label>
        <input type="password" id="password" class="form-control" v-model="password" required>
      </div>
      <div style="padding:10px"> 
        <button  type="submit" class="btn btn-danger">Register</button>
      </div>
      
    </form>
    <div v-if="error" class="error">{{ error }}</div>
  </div>
</template>

<script>
import axios from 'axios';

export default {
  name: 'UserRegister',
  data() {
    return {
      username: '',
      firstname: '',
      lastname: '',
      gender: '',
      address: '',
      mobile: '',
      dob: '',
      email: '',
      password: '',
      error: ''
    };
  },
  methods: {
    async register() {
      try {
        const response = await axios.post('http://localhost:3000/register', {
          username: this.username,
          email: this.email,
          password: this.password,
          firstname: this.firstname,
          lastname: this.lastname,
          gender: this.gender,
          address: this.address,
          mobile: this.mobile,
          dob: this.dob
        });
        console.log(response.data);
        alert('User registered successfully!');
        this.error = '';
      } catch (error) {
        console.error('Request failed:', error);
        if (error.response) {
          // Server responded with a status code outside the 2xx range
          this.error = `Error: ${error.response.data.message || error.response.statusText}`;
        } else if (error.request) {
          // Request was made but no response was received
          this.error = 'Error: No response from server. Please try again later.';
        } else {
          // Something else happened while setting up the request
          this.error = `Error: ${error.message}`;
        }
      }
    }
  }
};
</script>

<style scoped>
.user-register {
  max-width: 400px;
  margin: 0 auto;
}
.error {
  color: red;
  margin-top: 10px;
}
</style>
